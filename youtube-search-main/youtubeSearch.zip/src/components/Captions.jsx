import React from "react";
import { useEffect } from "react";
import { useState } from "react";

function Captions(props) {
  const [data, setData] = useState("");

  function checkParam(text, check) {
    if (text.includes(check)) {
      return true;
    }
  }



  useEffect(()=>{
    async function caption() {
      // var id = "K09xQuFdDuA"
      var id = props.id;
      const response = await fetch(
        `https://server-ten-iota.vercel.app/caption/?id=${id}`,
        {
          // mode: "no-cors",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Credentials": true,
        }
      );
      const captionData = await response.json();
      // var captionData = await getSubtitles({
      //   videoID: "aDG1T0kJnd4", // youtube video id
      //   lang: "en", // default: `en`
      // });
      if (captionData.data) {
        console.log(captionData.data);
        setData(captionData.data);
      } else {
        console.log(captionData.Error);
      }
    }
    caption();
  },[props.id])
  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{ flexDirection: "column" , width:"-webkit-fill-available"}}
    >
     
      {data && (
        <div
          style={{
            height: "200px",
            overflow: "scroll",
            width: "inherit",
            // background: "grey",
          }}
        >
          <div style={{backgroundColor:"blue", height:"10px", display:"flex", margin:"4px 0"}}>
          {data.map((data, i) => (
            <div key={i}
             style= {{background : checkParam(data.text ,props.data) && "yellow" , height:"auto", width:"2px"
            }}
              >
            </div>
          ))}
          </div>
          {data.map((data, i) => (
            <div key={i}>

              {checkParam(data.text ,props.data) && <p>{data.start}: {data.text} <br /></p>}
              
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Captions;